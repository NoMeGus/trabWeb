//teste com localStorage
const inputBox = document.querySelector(".inputField input");
const addBtn = document.querySelector(".inputField button");
const todoList = document.querySelector(".todoList");
const deleteAllBtn = document.querySelector(".footer #apagar");
const salvarBtn = document.querySelector(".footer #salvar")
arrayLocal = [];

document.getElementById("add").addEventListener("click", function(event){
  event.preventDefault()
});

document.getElementById("apagar").addEventListener("click", function(event){
  event.preventDefault()
});


inputBox.onkeyup = ()=>{
  let userEnteredValue = inputBox.value; 
  if(userEnteredValue.trim() != 0){ 
    addBtn.classList.add("active"); 
  }else{
    addBtn.classList.remove("active"); 
  }
}

addBtn.onclick = ()=>{ 
  let userEnteredValue = inputBox.value;
  arrayLocal.push(userEnteredValue);  
  showTasks(); 
  addBtn.classList.remove("active"); 
}
function showTasks(){
  const inputBox = document.querySelector(".inputField input");
  const addBtn = document.querySelector(".inputField button");
  const todoList = document.querySelector(".todoList");
  const deleteAllBtn = document.querySelector(".footer #apagar");
  const salvarBtn = document.querySelector(".footer #salvar")
  console.log(arrayLocal);
  const pendingTasksNumb = document.querySelector(".tarefasPendentes");
  pendingTasksNumb.textContent = arrayLocal.length; 
  if(arrayLocal.length > 0){ 
    deleteAllBtn.classList.add("active"); 
    salvarBtn.classList.add("active"); 
  }else{
    deleteAllBtn.classList.remove("active"); 
    salvarBtn.classList.remove("active"); 
  }
  let newLiTag = "";
  arrayLocal.forEach((element, index) => {
    newLiTag += `<li>${element}<span class="icon" onclick="deleteTask(${index})"><ion-icon name="trash-outline">Excluir</ion-icon></span></li>`;
  });
  todoList.innerHTML = newLiTag; 
  inputBox.value = ""; 

  document.getElementById("add").addEventListener("click", function(event){
    event.preventDefault()
  });
  
  document.getElementById("apagar").addEventListener("click", function(event){
    event.preventDefault()
  });

  addBtn.onclick = ()=>{ 
    let userEnteredValue = inputBox.value;
    arrayLocal.push(userEnteredValue);  
    showTasks(); 
    addBtn.classList.remove("active"); 
  }

  inputBox.onkeyup = ()=>{
    let userEnteredValue = inputBox.value; 
    if(userEnteredValue.trim() != 0){ 
      addBtn.classList.add("active"); 
    }else{
      addBtn.classList.remove("active"); 
    }     
  }
  deleteAllBtn.onclick = ()=>{
    listArray = []; 
    arrayLocal = listArray;
    showTasks(); 
  }
  
  salvarBtn.onclick = ()=>{
    createCookie("lcl", JSON.stringify(arrayLocal), 10)
    arrayLocal = []; 
    showTasks(); 
  }
}

function deleteTask(index){
  listArray = arrayLocal;
  listArray.splice(index, 1); 
  arrayLocal = listArray;
  showTasks(); 
}

deleteAllBtn.onclick = ()=>{
  listArray = []; 
  arrayLocal = listArray;
  showTasks(); 
}

salvarBtn.onclick = ()=>{
  createCookie("lcl", JSON.stringify(arrayLocal), 10)
  arrayLocal = []; 
  showTasks(); 
}

// Function to create the cookie
function createCookie(name, value, days) {
  var expires;

  if (days) {
    var date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    expires = "; expires=" + date.toGMTString();
  }
  else {
    expires = "";
  }

  document.cookie = escape(name) + "=" + escape(value) + expires + "; path=/";
}

function validatePrivate() {
  var check_public = document.getElementsById("check_public")[0];  
  var check_private = document.getElementsById('check_private')[0];
    if (check_private.checked) {
      check_public.checked = false;
      check_public.value = 'off';
    }
}

function validatePublic() {
  var check_public = document.getElementsById("check_public")[0];
  var check_private = document.getElementsById('check_private')[0];
  if (check_public.checked) {
    check_private.checked = false;
    check_private.value = 'off';
  } 
}
