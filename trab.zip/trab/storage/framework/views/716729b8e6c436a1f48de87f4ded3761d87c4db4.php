<!DOCTYPE html>
<html lang="en">
<head>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/menu.css">
    <title>Início</title>
    <script src="/js/script.js"></script>
</head>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Página Inicial')); ?>

        </h2>

     <?php $__env->endSlot(); ?>
    <y-slot name="body">

    <section class="lista-flex">
        
    </section>

    </y-slot>
    <z-slot name="footer">
    <footer>
        <div class="middle-content">
            <input type="text" id="busca" placeholder="Pesquisar por lista ou tarefas">
            <button><ion-icon name="search-outline" class="search-icon"></ion-icon></button>
        </div>


        <div class="right-content">
            <a type="button" href='/criar'><ion-icon name="add-outline" class="add-icon"></ion-icon></a>
            <p>Nova lista</p>
        </div>
    </footer>
    </z-slot>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\brunn\OneDrive\Área de Trabalho\trab_bd_branch_brunno\LBD-ToDoList\trabLBD\resources\views/list/dashboard.blade.php ENDPATH**/ ?>