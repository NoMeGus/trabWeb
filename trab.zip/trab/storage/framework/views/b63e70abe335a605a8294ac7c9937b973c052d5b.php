<!DOCTYPE html>
<html lang="en">
<head>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="criar.css">
    <title>Criar nota</title>
</head>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Página Inicial')); ?>

        </h2>

     <?php $__env->endSlot(); ?>

<y-slot name="body">
        
            <!-- tentando-->
            <div class="tela-criacao">
                
                <div class="input-titulo"><input type="text" placeholder="Criar título"></div>



                <div class="inputField">
                  <input type="text" placeholder="Adicione nova tarefa">
                  <button><ion-icon name="add-outline" class="add-icon"></ion-icon></button>
                </div>
                <ul class="todoList">
                  <!-- dados vindo do armazenamento local -->
                </ul>
                <div class="footer">
                  <span> Total de <span class="tarefasPendentes"></span> tarefas</span>
                  <button id="salvar">Salvar</button>
                  <button id="apagar">Apagar tudo</button>
                </div>
              </div>
              <script src="/js/script.js"></script>
</y-slot>
<z-slot name="footer">
<footer><ion-icon class="voltar" name="arrow-back-circle-outline"></ion-icon>
    </footer>
</z-slot>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\brunn\OneDrive\Área de Trabalho\trab_bd_branch_brunno\LBD-ToDoList\trabLBD\resources\views/criar.blade.php ENDPATH**/ ?>