<div class="hidden sm:block">
    <div class="py-8">
        <div class="border-t border-gray-200"></div>
    </div>
</div>
<?php /**PATH C:\Users\brunn\OneDrive\Área de Trabalho\trab_bd_branch_brunno\trabLBD\vendor\laravel\jetstream\src/../resources/views/components/section-border.blade.php ENDPATH**/ ?>