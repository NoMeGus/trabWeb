<!DOCTYPE html>
<html lang="en">
<head>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/rascunho.css">
    <title>Rascunho</title>
</head>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'teste']); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Rascunho')); ?>

        </h2>

     <?php $__env->endSlot(); ?>
    <div class="meio">
    <form action="/update-rascunho" method="post">
        <?php echo csrf_field(); ?>
        <textarea name="textarea" placeholder="Faça suas anotações" id="textarea" cols="30" rows="10"><?php echo e($rascunho->descricao); ?></textarea><br>
        <button class="button" type="submit">Salvar</button>
    </form>
    </div>
    
<a href="/dashboard"><ion-icon class="voltar" name="arrow-back-circle-outline"></ion-icon></a>   
    

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\LBD-ToDoList\trabLBD\resources\views/rascunho.blade.php ENDPATH**/ ?>