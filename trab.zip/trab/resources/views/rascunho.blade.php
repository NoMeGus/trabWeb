<!DOCTYPE html>
<html lang="en">
<head>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/rascunho.css">
    <title>Rascunho</title>
</head>

<x-app-layout class="teste">
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Rascunho') }}
        </h2>

    </x-slot>
    <div class="meio">
    <form action="/update-rascunho" method="post">
        @csrf
        <textarea name="textarea" placeholder="Faça suas anotações" id="textarea" cols="30" rows="10">{{$rascunho->descricao}}</textarea><br>
        <button class="button" type="submit">Salvar</button>
    </form>
    </div>
    
<a href="/dashboard"><ion-icon class="voltar" name="arrow-back-circle-outline"></ion-icon></a>   
    

</x-app-layout>
