<!DOCTYPE html>
<html lang="en">
<head>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/criar.css">
    <title>Editar Lista</title>

    <script src="/js/script.js"></script>
</head>
<body onload="showTasks()">
<x-app-layout>
<script>
                  <?php
                    echo 'arrayLocal = JSON.parse(\''.json_encode($task).'\')';
                  ?>
                </script>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Editar Lista') }}
        </h2>

    </x-slot>

            <!-- tentando-->
            <form action="/update/{{$list->id}}" method='GET'>
            @csrf
            @method('PUT')
            <div class="tela-criacao">
                <div class="input-titulo"><input name='task' type="text" placeholder="{{$list->titulo}}" value="{{$list->titulo}}"></div>
                @if ($list->publica == true)
                <div class='container-checkbox'>
                    Publica: <input  type="radio" checked name="check" value="1">
                    <span class='espaco'>
                    Privada: <input  type="radio" name="check" value="0">
                  </span>
                </div>
                @else
                <div class='container-checkbox'>
                  Publica: <input type="radio" id="check_public" name="check" value="1">
                  <span class='espaco'>
                  Privada: <input  type="radio" checked name="check" value="0">
                  </span>
                </div>
                @endif
                <div class="inputField">
                  <input type="text" placeholder="Adicione nova tarefa">
                  <button id='add'><ion-icon name="add-outline" class="add-icon"></ion-icon></button>
                </div>
                <ul class="todoList">
                  <!-- dados vindo do armazenamento local -->
                </ul>
                <div class="footer">
                  <span> Total de <span class="tarefasPendentes"></span> tarefas</span>
                  <button id="salvar" type='submit'>Salvar</button>
                  <button id="apagar">Apagar tudo</button>
                </div>
              </div>  
            </form>
   
<z-slot name="footer">
<footer><a href="/dashboard"><ion-icon class="voltar" name="arrow-back-circle-outline"></ion-icon></a>
    </footer>
</z-slot>
</x-app-layout>
</body>