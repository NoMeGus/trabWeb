<!DOCTYPE html>
<html lang="en">
<head>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/menu.css">
    <title>Início</title>
    <script src="/js/script.js"></script>
</head>

<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Página Inicial') }}
        </h2>

    </x-slot>
    <y-slot name="body">

    <section class="lista-flex">
            @foreach ($lists as $list)
                @if ($list->publica == true)
                <div>
                <form action="/dashboard/{{ $list->id }}" method='POST' style='width:100%'>
                            @csrf
                            @method('DELETE')
                            <button type='submit' style="color:rgb(216, 83, 83);">Excluir<ion-icon class='deleteButton'name="trash-outline"></ion-icon></button>
                        </form>
                    <p>Lista Pública:</p>
                    <form action="/editarlista/ {{$list->id}}">
                       <button><p>Título: {{$list->titulo}}  <ion-icon class="editButton" name="create-outline"></p></button>
                    </form>
                    @foreach ($tarefa as $tl)
                        @if ($list->id == $tl->lista_id)
                            <p>{{$tl->descricao}}</p>
                        @endif 
                    @endforeach
                </div>
                @endif
            @endforeach
            @foreach ($listuser as $listprivate)
                @if ($listprivate->publica == false)
                    <div>
                    <form action="/dashboard/{{ $listprivate->id }}" method='POST'>
                            @csrf
                            @method('DELETE')
                        <button type='submit' style="color:rgb(216, 83, 83);"> Excluir<ion-icon class='deleteButton'name="trash-outline"></ion-icon></button>
                        </form>

                        <form action="/editarlista/{{$listprivate->id}}">                                       
                            <button><p>Título: {{$listprivate->titulo}}  <ion-icon class="editButton" name="create-outline"></ion-icon></p> </button>
                        </form>
                        @foreach ($tarefa as $tl)
                        @if ($listprivate->id == $tl->lista_id)
                            <p>{{$tl->descricao}}</p>
                        @endif 
                        @endforeach

                    </div>
                @endif
            @endforeach
        
    </section>

    </y-slot>
    <z-slot name="footer">
    <footer>

        <div class="left-content">
                <a type="button" href='/rascunho'><ion-icon name="document-text-outline" class="add-icon"></ion-icon></a>
                <p>Rascunho</p>
        </div>

        <div class="middle-content">
            <form  action="/dashboardBusca" method="GET">
            <input type="text" id="search" name="search" placeholder="Pesquisar por lista ou tarefas">
            <button><ion-icon name="search-outline" class="search-icon"></ion-icon></button></form>
        </div>


        <div class="right-content">
            <a type="button" href='/criar'><ion-icon name="add-outline" class="add-icon"></ion-icon></a>
            <p>Nova lista</p>
        </div>
    </footer>
    </z-slot>
</x-app-layout>
