<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\Lista;
use App\Models\ListaUser;
use App\Models\Tarefa;
use Illuminate\Support\Facades\DB;
use App\Models\Rascunho;
use Illuminate\Http\Request;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function dashboard() {   

        $listUser = DB::table('lista_user')
            ->join('listas', function ($join) {
                $join->on('listas.id', '=', 'lista_user.lista_id') 
                    ->where('lista_user.user_id', '=', auth()->user()->id);
            })->get();
        
        $tarefa = Tarefa::all();
        $lists = Lista::all();
        
        return view('dashboard', ['lists' => $lists, 'listuser' => $listUser, 'tarefa' => $tarefa]);
    }

    public function editar($id) {
        $array = [];
        $cookieArray;
        $list = Lista::findOrFail($id);
        $task = Tarefa::where('lista_id', $id)->get();
        foreach ($task as $tasks) {
            array_push($array, $tasks->descricao);
        }
        return view('editarlista', ['list' => $list], ['task' => $array]);
    }

    public function rascunho() {
        $user = auth()->user()->id;
        $rascunho = Rascunho::where('user_id', $user)->firstOrFail();
        
        return view('rascunho', ['rascunho' => $rascunho]);
    }

    public function update_rascunho(Request $request) {
        $user = auth()->user()->id;
        Rascunho::where('user_id', '=', $user)->firstOrFail()->update(['descricao' => $request->textarea]);
        $rascunho = Rascunho::where('user_id', $user)->firstOrFail();
        return view('rascunho', ['rascunho' => $rascunho]);
    }


    public function buscar(){
        $search=request('search');
        $tarefa = Tarefa::all();
        


        $listUser = DB::table('lista_user')     
                ->where('lista_user.user_id', '=', auth()->user()->id)              
        ->get(); 

        if($search){
        
            $lists=Lista::where([
                ['titulo', 'like', '%'.$search.'%']
            ])->get();

        
         }else {
            $lists=Lista::all();
        }

        if($search){
        
            $listUser=Lista::where([
                ['titulo', 'like', '%'.$search.'%']
            ])->get();

        
         }else {
            $listUser=Lista::all();
        }

        return view('dashboard',['lists'=>$lists, 'search'=>$search, 'listuser' => $listUser, 'tarefa' => $tarefa]);
    }
}
