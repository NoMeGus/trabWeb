<?php

namespace App\Http\Controllers;

use App\Models\Lista;
use App\Models\Tarefa;
use Illuminate\Http\Request;

class ListaController extends Controller
{
    public function storeList($request) {
        $list = new Lista;
        $tarefas = json_decode($_COOKIE['lcl']);
        if ($request->check == 0)
        {
            $list->titulo = $request->task;
            $list->nmr_tarefas = sizeOf($tarefas);
            $list->publica = false;
            $list->save();
        }
        else {
            $list->titulo = $request->task;
            $list->nmr_tarefas = sizeOf($tarefas);
            $list->publica = true;
            $list->save();
        }
        return $list->id;
    }

    public function storeTask($request, $id) {
        $tarefas = json_decode($_COOKIE['lcl']);
        foreach($tarefas as $values) {
            $task = new Tarefa;
            $task->lista_id = $id;
            $task->descricao = $values;
            $task->save();
        }
        
    }

    public function FeedManyToMany($id) {
        $user = auth()->user();
        $user->lists()->attach($id);
    }

    public function index() {
        return view('/criar');
    }

    public function create(Request $request) {
        $getId_lista = $this->storeList($request);
        $this->storeTask($request, $getId_lista);
        $this->FeedManyToMany($getId_lista);
        return view('/criar');
    }

    public function destroy($id) {
        Lista::findOrFail($id)->delete();

        return redirect('dashboard');
    }

    public function update(Request $request, $lista_id) {
        Lista::findOrFail($request->id)->tarefas()->delete();
        $this->storeTask($request, $request->id);
    

        if ($request->check == 0)
        {
            Lista::findOrFail($request->id)->update(['titulo'=> $request->task, 'publica'=> false]);
        }
        else {
            Lista::findOrFail($request->id)->update(['titulo'=> $request->task, 'publica'=> true]);
        }
        return redirect('dashboard');
    }

}
