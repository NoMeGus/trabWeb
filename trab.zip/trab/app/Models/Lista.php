<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Model\Tarefa;

class Lista extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function users() {
        return $this->belongsToMany('App\Model\User');
    }

    public function tarefas() {
        return $this->hasMany('App\Models\Tarefa');
    }

}
