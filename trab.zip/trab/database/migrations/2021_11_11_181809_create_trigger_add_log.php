<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTriggerAddLog extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared('CREATE TRIGGER createLista AFTER INSERT
        ON lista_user
        FOR EACH ROW
        BEGIN 
        INSERT INTO `tabela_log` (`user_id`, `modify`, `description`) VALUES (NEW.user_id, \'INSERT\', \'Created new lista\');
        END');

        DB::unprepared('CREATE TRIGGER createRascunho AFTER INSERT
        ON rascunhos
        FOR EACH ROW
        BEGIN
        INSERT INTO `tabela_log` (`user_id`, `modify`, `description`) VALUES (NEW.user_id, \'INSERT\', \'Created new rascunho\');
        END');

        DB::unprepared('CREATE TRIGGER deleteLista AFTER DELETE
        ON lista_user
        FOR EACH ROW
        BEGIN
        INSERT INTO `tabela_log` (`user_id`, `modify`, `description`) VALUES (OLD.user_id, \'DELETE\', \'Deleted lista\');
        END');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('trigger_add_log');
    }
}
